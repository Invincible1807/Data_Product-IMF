import requests
import pandas as pd
import psycopg2
from psycopg2 import sql
from datetime import datetime
import logging
import time
from sqlalchemy import create_engine

# Configure logging
logging.basicConfig(filename="etl_pipeline.log", level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# PostgreSQL connection parameters
DB_CONFIG = {
    "dbname": "mutual_funds_db",
    "user": "postgres",
    "password": "adityA$853211",
    "host": "localhost",
    "port": "5432"
}

# AMFI Historical NAV Data URL
AMFI_URL = "https://www.amfiindia.com/spages/NAVAll.txt"


# Fetch NAV Data with retry mechanism
def fetch_amfi_data(retries=3, delay=5):
    for attempt in range(retries):
        try:
            response = requests.get(AMFI_URL, timeout=10)
            if response.status_code == 200:
                return response.text
            else:
                logging.error(f"Failed to fetch AMFI data. Status Code: {response.status_code}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Network error: {e}. Retrying ({attempt + 1}/{retries})...")
            time.sleep(delay)

    return None


# Process the NAV data with missing value handling
def process_nav_data(data):
    lines = data.split("\n")[1:]  # Skip headers
    nav_records = []
    today = datetime.today().strftime("%Y-%m-%d")

    for line in lines:
        cols = line.strip().split(";")
        if len(cols) < 5:
            continue

        try:
            scheme_code = cols[0].strip()
            scheme_name = cols[1].strip() or "Unknown Scheme"
            net_asset_value = float(cols[4].strip()) if cols[4].strip() else None
            nav_date = cols[5].strip() if len(cols) > 5 else today

            # Handle missing values
            if not scheme_code or not nav_date:
                continue  # Skip records with essential data missing
            if net_asset_value is None:
                net_asset_value = 0.0  # Default value for missing NAV

            nav_records.append((scheme_code, scheme_name, net_asset_value, nav_date))

        except ValueError as e:
            logging.warning(f"Error parsing line: {line}. Error: {e}")

    return nav_records


# Insert into PostgreSQL and track inserted rows
def insert_nav_data(nav_records):
    conn = None
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cursor = conn.cursor()

        # Move old data from mutual_fund_nav to history
        cursor.execute("""
            INSERT INTO mutual_fund_nav_history (scheme_code, scheme_name, net_asset_value, nav_date)
            SELECT scheme_code, scheme_name, net_asset_value, nav_date FROM mutual_fund_nav
            WHERE nav_date < CURRENT_DATE;
        """)
        moved_rows = cursor.rowcount  # Count moved rows

        cursor.execute("DELETE FROM mutual_fund_nav WHERE nav_date < CURRENT_DATE;")

        history_inserted = 0
        current_inserted = 0

        # Insert fresh NAV data
        for record in nav_records:
            cursor.execute("""
                INSERT INTO mutual_fund_nav_history (scheme_code, scheme_name, net_asset_value, nav_date)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (scheme_code, nav_date) DO NOTHING;
            """, record)
            history_inserted += cursor.rowcount  # Count inserted rows

            if record[3] == datetime.today().strftime("%Y-%m-%d"):
                cursor.execute("""
                    INSERT INTO mutual_fund_nav (scheme_code, scheme_name, net_asset_value, nav_date)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (scheme_code) DO UPDATE
                    SET net_asset_value = EXCLUDED.net_asset_value, nav_date = EXCLUDED.nav_date;
                """, record)
                current_inserted += cursor.rowcount  # Count inserted rows

        conn.commit()
        logging.info(f"Data inserted successfully.")
        logging.info(f"Records moved to history: {moved_rows}")
        logging.info(f"New records inserted into mutual_fund_nav_history: {history_inserted}")
        logging.info(f"New records inserted into mutual_fund_nav: {current_inserted}")

        print(f"Data inserted successfully.")
        print(f"Records moved to history: {moved_rows}")
        print(f"New records inserted into mutual_fund_nav_history: {history_inserted}")
        print(f"New records inserted into mutual_fund_nav: {current_inserted}")

        # Export the latest data to an Excel file
        export_to_excel(conn)
        # engine = create_engine('postgresql://postgres:adityA$853211@localhost:5432/mutual_funds_db')
        # export_to_excel(engine)


    except Exception as e:
        logging.error(f"Database error: {e}")
        print("Database error:", e)

    finally:
        if conn:
            conn.close()


# Export data to Excel with timestamp
def export_to_excel(conn):
    try:
        query_history = "SELECT * FROM mutual_fund_nav_history;"
        query_current = "SELECT * FROM mutual_fund_nav;"

        df_history = pd.read_sql(query_history, conn)
        df_current = pd.read_sql(query_current, conn)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_name = f"mutual_fund_data_{timestamp}.xlsx"

        with pd.ExcelWriter(file_name, engine="xlsxwriter") as writer:
            df_history.to_excel(writer, sheet_name="Historical NAV", index=False)
            df_current.to_excel(writer, sheet_name="Current NAV", index=False)

        logging.info(f"Excel file '{file_name}' created successfully.")
        print(f"Excel file '{file_name}' created successfully.")

    except Exception as e:
        logging.error(f"Error exporting data to Excel: {e}")
        print("Error exporting data to Excel:", e)


# # Correct Engine Creation
# engine = create_engine('postgresql://postgres:adityA$853211@localhost:5432/mutual_funds_db')

# # Export data to Excel with timestamp
# def export_to_excel(engine):
#     try:
#         query_history = "SELECT * FROM mutual_fund_nav_history;"
#         query_current = "SELECT * FROM mutual_fund_nav;"
#
#         # Correct method for SQLAlchemy connection
#         with engine.connect() as conn:
#             df_history = pd.read_sql(query_history, conn)
#             df_current = pd.read_sql(query_current, conn)
#
#         timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#         file_name = f"mutual_fund_data_{timestamp}.xlsx"
#
#         with pd.ExcelWriter(file_name, engine="xlsxwriter") as writer:
#             df_history.to_excel(writer, sheet_name="Historical NAV", index=False)
#             df_current.to_excel(writer, sheet_name="Current NAV", index=False)
#
#         logging.info(f"Excel file '{file_name}' created successfully.")
#         print(f"Excel file '{file_name}' created successfully.")
#
#     except Exception as e:
#         logging.error(f"Error exporting data to Excel: {e}")
#         print("Error exporting data to Excel:", e)



# Validate Database Schema
def validate_database_schema():
    conn = None
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cursor = conn.cursor()

        # Check required tables
        cursor.execute("""
            SELECT table_name FROM information_schema.tables
            WHERE table_schema = 'public' AND table_name IN ('mutual_fund_nav', 'mutual_fund_nav_history');
        """)
        tables = [row[0] for row in cursor.fetchall()]

        if "mutual_fund_nav" not in tables or "mutual_fund_nav_history" not in tables:
            raise Exception("Required tables not found in database.")

        logging.info("Database schema validation passed.")
        print("Database schema validation passed.")

    except Exception as e:
        logging.error(f"Database schema validation failed: {e}")
        print("Database schema validation failed:", e)

    finally:
        if conn:
            conn.close()


# Run the ETL Pipeline
if __name__ == "__main__":
    logging.info("ETL pipeline started.")

    # Validate database before running ETL
    validate_database_schema()

    data = fetch_amfi_data()
    if data:
        nav_records = process_nav_data(data)
        insert_nav_data(nav_records)

    logging.info("ETL pipeline completed.")


# ✅ Runs all functions in sequence:
# 1️⃣ Database Validation
# 2️⃣ Data Fetching
# 3️⃣ Data Processing
# 4️⃣ Data Insertion
# 5️⃣ Data Export

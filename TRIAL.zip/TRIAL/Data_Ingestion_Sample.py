import pandas as pd
import psycopg2
import requests
from datetime import datetime, timedelta

# PostgreSQL Connection
DB_PARAMS = {
    "dbname": "mutual_funds_db",
    "user": "postgres",
    "password": "adityA$853211",
    "host": "localhost",
    "port": "5432"
}

# AMFI Data URL
AMFI_URL = "https://www.amfiindia.com/spages/NAVAll.txt"


def fetch_amfi_data():
    """Fetch AMFI Mutual Fund Data."""
    response = requests.get(AMFI_URL)
    if response.status_code == 200:
        return response.text
    else:
        print("❌ Failed to fetch data")
        return None


def clean_data(raw_data):
    """Cleans and extracts mutual fund data into DataFrame."""
    lines = raw_data.split("\n")
    data_rows = []

    for line in lines:
        # Skip empty lines and metadata lines (headers)
        if not line.strip() or "Scheme Code" in line or "Open Ended Schemes" in line:
            continue

        # Split by semicolon
        parts = line.split(";")

        # Ensure we have at least 6 columns (Scheme Code, ISINs, Scheme Name, NAV, Date)
        if len(parts) >= 6:
            scheme_code = parts[0].strip()
            scheme_name = parts[3].strip()
            nav_value = parts[4].strip()
            nav_date = parts[5].strip()

            # Validate data format
            if scheme_code.isdigit() and nav_value.replace('.', '', 1).isdigit():
                data_rows.append([scheme_code, scheme_name, float(nav_value), nav_date])

    # Convert to DataFrame
    df = pd.DataFrame(data_rows, columns=["Scheme_Code", "Scheme_Name", "Net_Asset_Value", "NAV_Date"])

    # Convert Date Column
    df["NAV_Date"] = pd.to_datetime(df["NAV_Date"], format="%d-%b-%Y", errors="coerce")

    print(f"📊 Extracted {len(df)} rows")
    print(df.head())

    return df.dropna()


def insert_into_postgresql(df, table_name):
    """Inserts DataFrame into a specified PostgreSQL table."""
    if df.empty:
        print(f"⚠️ No valid data to insert into {table_name}")
        return

    conn = psycopg2.connect(**DB_PARAMS)
    conn.autocommit = True  # Ensures changes are committed
    cursor = conn.cursor()

    # Debug: Check schema search path
    cursor.execute("SHOW search_path;")
    print(f"🔍 Current search path: {cursor.fetchone()[0]}")

    create_table_query = f"""
    CREATE TABLE IF NOT EXISTS {table_name} (
        scheme_code INT,
        scheme_name TEXT,
        net_asset_value DECIMAL,
        nav_date DATE,
        PRIMARY KEY (scheme_code, nav_date)
    );
    """
    cursor.execute(create_table_query)
    conn.commit()

    insert_query = f"""
    INSERT INTO {table_name} (scheme_code, scheme_name, net_asset_value, nav_date)
    VALUES (%s, %s, %s, %s)
    ON CONFLICT (scheme_code, nav_date) DO UPDATE 
    SET net_asset_value = EXCLUDED.net_asset_value;
    """
    cursor.executemany(insert_query, df.values)
    conn.commit()

    # Debug: Check if data is inserted
    cursor.execute(f"SELECT COUNT(*) FROM {table_name};")
    total_rows = cursor.fetchone()[0]
    print(f"✅ Inserted {len(df)} records into {table_name}. Total rows now: {total_rows}")

    cursor.close()
    conn.close()


def process_last_10_days(df):
    """Filters last 10 days' NAV data for history table."""
    today = datetime.today().date()
    last_10_days = today - timedelta(days=10)

    # Ensure NAV_Date is in proper format
    df["NAV_Date"] = pd.to_datetime(df["NAV_Date"]).dt.date

    # Filter last 10 days' data
    df_last_10 = df[(df["NAV_Date"] < today) & (df["NAV_Date"] >= last_10_days)]

    print(f"📌 Historical Data Filtered: {len(df_last_10)} rows")
    return df_last_10


# 🚀 Run Pipeline
raw_data = fetch_amfi_data()
if raw_data:
    df = clean_data(raw_data)

    # Insert today's NAV data into `mutual_fund_nav`
    today_date = datetime.today().date()
    df_today = df[df["NAV_Date"] == pd.to_datetime(today_date)]
    insert_into_postgresql(df_today, "mutual_fund_nav")

    # Insert last 10 days' NAV data into `mutual_fund_nav_history`
    df_last_10_days = process_last_10_days(df)
    insert_into_postgresql(df_last_10_days, "mutual_fund_nav_history")


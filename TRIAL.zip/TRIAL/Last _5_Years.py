import requests
import pandas as pd
import psycopg2
from datetime import datetime

# PostgreSQL connection parameters
DB_CONFIG = {
    "dbname": "mutual_funds_db",
    "user": "postgres",
    "password": "adityA$853211",
    "host": "localhost",
    "port": "5432"
}

# AMFI Historical NAV Data URL
AMFI_URL = "https://www.amfiindia.com/spages/NAVAll.txt"


# Fetch NAV Data
def fetch_amfi_data():
    response = requests.get(AMFI_URL)
    if response.status_code == 200:
        return response.text
    else:
        print("Failed to fetch AMFI data")
        return None


# Process the NAV data
def process_nav_data(data):
    lines = data.split("\n")[1:]  # Skip headers
    nav_records = []
    today = datetime.today().strftime("%d-%b-%Y")

    for line in lines:
        cols = line.strip().split(";")
        if len(cols) < 5:
            continue

        try:
            scheme_code = cols[0].strip()
            scheme_name = cols[1].strip()
            net_asset_value = float(cols[4].strip()) if cols[4].strip() else None
            nav_date = cols[5].strip() if len(cols) > 5 else today

            if net_asset_value is not None:
                nav_records.append((scheme_code, scheme_name, net_asset_value, nav_date))

        except ValueError as e:
            print(f"Error parsing line: {line}, Error: {e}")

    return nav_records


# Insert into PostgreSQL and count inserted rows
def insert_nav_data(nav_records):
    conn = None
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cursor = conn.cursor()

        # Move old data from mutual_fund_nav to history
        cursor.execute("""
            INSERT INTO mutual_fund_nav_history (scheme_code, scheme_name, net_asset_value, nav_date)
            SELECT scheme_code, scheme_name, net_asset_value, nav_date FROM mutual_fund_nav
            WHERE nav_date < CURRENT_DATE;
        """)
        moved_rows = cursor.rowcount  # Count moved rows
        cursor.execute("DELETE FROM mutual_fund_nav WHERE nav_date < CURRENT_DATE;")

        history_inserted = 0
        current_inserted = 0

        # Insert fresh NAV data
        for record in nav_records:
            cursor.execute("""
                INSERT INTO mutual_fund_nav_history (scheme_code, scheme_name, net_asset_value, nav_date)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (scheme_code, nav_date) DO NOTHING;
            """, record)
            history_inserted += cursor.rowcount  # Count inserted rows

            if record[3] == datetime.today().strftime("%d-%b-%Y"):
                cursor.execute("""
                    INSERT INTO mutual_fund_nav (scheme_code, scheme_name, net_asset_value, nav_date)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (scheme_code) DO UPDATE
                    SET net_asset_value = EXCLUDED.net_asset_value, nav_date = EXCLUDED.nav_date;
                """, record)
                current_inserted += cursor.rowcount  # Count inserted rows

        conn.commit()
        print(f"Data inserted successfully.")
        print(f"Records moved to history: {moved_rows}")
        print(f"New records inserted into mutual_fund_nav_history: {history_inserted}")
        print(f"New records inserted into mutual_fund_nav: {current_inserted}")

        # Export the latest data to an Excel file
        export_to_excel(conn)

    except Exception as e:
        print("Database error:", e)

    finally:
        if conn:
            conn.close()


# Export data to Excel
def export_to_excel(conn):
    try:
        query_history = "SELECT * FROM mutual_fund_nav_history;"
        query_current = "SELECT * FROM mutual_fund_nav;"

        df_history = pd.read_sql(query_history, conn)
        df_current = pd.read_sql(query_current, conn)

        file_name = "mutual_fund_data.xlsx"
        with pd.ExcelWriter(file_name, engine="xlsxwriter") as writer:
            df_history.to_excel(writer, sheet_name="Historical NAV", index=False)
            df_current.to_excel(writer, sheet_name="Current NAV", index=False)

        print(f"Excel file '{file_name}' created successfully in the current directory.")

    except Exception as e:
        print("Error exporting data to Excel:", e)


# Run the ETL Pipeline
if __name__ == "__main__":
    data = fetch_amfi_data()
    if data:
        nav_records = process_nav_data(data)
        insert_nav_data(nav_records)
